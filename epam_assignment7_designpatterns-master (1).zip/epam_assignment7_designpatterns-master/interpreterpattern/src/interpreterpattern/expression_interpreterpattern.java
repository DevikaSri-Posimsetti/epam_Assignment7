package interpreterpattern;

public interface expression_interpreterpattern {
	public boolean interpret(String context);

}
