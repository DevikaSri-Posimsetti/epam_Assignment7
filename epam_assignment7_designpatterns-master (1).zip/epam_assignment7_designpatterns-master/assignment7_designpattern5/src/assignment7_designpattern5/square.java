package assignment7_designpattern5;

public class square implements draw_shape{
	 public void draw() {
	      System.out.println("In square.draw() method");
	   }
	

}
