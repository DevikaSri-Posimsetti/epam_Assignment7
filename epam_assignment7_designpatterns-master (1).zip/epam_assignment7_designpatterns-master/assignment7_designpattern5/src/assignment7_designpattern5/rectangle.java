package assignment7_designpattern5;

public class rectangle implements draw_shape{
	 public void draw() {
	      System.out.println("In rectangle.draw() method");
	   }

}
