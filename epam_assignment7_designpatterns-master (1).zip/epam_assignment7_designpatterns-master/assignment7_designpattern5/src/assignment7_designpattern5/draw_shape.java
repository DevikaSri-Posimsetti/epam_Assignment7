package assignment7_designpattern5;

public interface draw_shape {
	void draw();

}
