package assignment7_designpattern5;

abstract public class abstractfactory {
	abstract draw_shape getshape(String shapeType) ;

}
