package assignment7_designpattern5;

public class rounded_square implements draw_shape{
	 public void draw() {
	      System.out.println("In rounded_square.draw() method");
	   }

}
