package assignment7_designpattern5;

public class rounded_rectangle implements draw_shape{
	 public void draw() {
	      System.out.println("In rounded_rectangle.draw() method");
	   }

}
