package assignment7_designpatterns;

public class sparrow_designpattern1 implements bird_designpattern1 { 
    public void fly() 
    { 
        System.out.println("Fly"); 
    } 
    public void makeSound() 
    { 
        System.out.println("Chirp"); 
    } 

}
