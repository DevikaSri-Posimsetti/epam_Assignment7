package assignment7_designpatterns;

public interface playtoy_designpattern1 {
	    public void squeak();

}
