package assignment7_designpatterns;

public interface bird_designpattern1 {
		public void fly(); 
	    public void makeSound();
}
