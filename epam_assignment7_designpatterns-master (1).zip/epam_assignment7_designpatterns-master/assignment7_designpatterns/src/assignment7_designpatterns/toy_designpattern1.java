package assignment7_designpatterns;

public class toy_designpattern1 implements playtoy_designpattern1
{ 
    public void squeak() 
    { 
        System.out.println("Squeak"); 
    }

}
