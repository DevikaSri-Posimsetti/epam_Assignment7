package assignment7_designpatterns2;

public interface command_designpattern2 {
	public void execute();

}
