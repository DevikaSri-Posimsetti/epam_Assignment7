package assignment7_designpatterns2;

public class switch_designpattern2 {
	private boolean on;
	  public void switch_on(){
	    on=true;
	  }
	  public void switch_off(){
	    on=false;
	  }

}
